# סכרת

Brain: בריאות ותזונה
SubBrain: סכרת

Purpose:
This folder is part of the Personal Brain structure.