# ירידה במשקל

Brain: בריאות ותזונה
SubBrain: ירידה במשקל

Purpose:
This folder is part of the Personal Brain structure.