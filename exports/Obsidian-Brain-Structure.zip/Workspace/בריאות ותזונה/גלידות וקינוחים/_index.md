# גלידות וקינוחים

Brain: בריאות ותזונה
SubBrain: גלידות וקינוחים

Purpose:
This folder is part of the Personal Brain structure.