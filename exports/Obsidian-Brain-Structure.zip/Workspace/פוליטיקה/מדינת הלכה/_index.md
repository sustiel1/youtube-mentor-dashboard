# מדינת הלכה

Brain: פוליטיקה
SubBrain: מדינת הלכה

Purpose:
This folder is part of the Personal Brain structure.