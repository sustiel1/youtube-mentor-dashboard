# כלכלה וחברה

Brain: פוליטיקה
SubBrain: כלכלה וחברה

Purpose:
This folder is part of the Personal Brain structure.