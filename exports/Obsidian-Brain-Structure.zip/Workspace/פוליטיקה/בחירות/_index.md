# בחירות

Brain: פוליטיקה
SubBrain: בחירות

Purpose:
This folder is part of the Personal Brain structure.