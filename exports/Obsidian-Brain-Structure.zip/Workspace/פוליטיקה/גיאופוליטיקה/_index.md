# גיאופוליטיקה

Brain: פוליטיקה
SubBrain: גיאופוליטיקה

Purpose:
This folder is part of the Personal Brain structure.