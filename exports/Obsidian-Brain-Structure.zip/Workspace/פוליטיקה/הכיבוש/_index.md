# הכיבוש

Brain: פוליטיקה
SubBrain: הכיבוש

Purpose:
This folder is part of the Personal Brain structure.