# תקשורת ותעמולה

Brain: פוליטיקה
SubBrain: תקשורת ותעמולה

Purpose:
This folder is part of the Personal Brain structure.