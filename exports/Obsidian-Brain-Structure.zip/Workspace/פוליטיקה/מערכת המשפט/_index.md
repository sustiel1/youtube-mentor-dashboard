# מערכת המשפט

Brain: פוליטיקה
SubBrain: מערכת המשפט

Purpose:
This folder is part of the Personal Brain structure.