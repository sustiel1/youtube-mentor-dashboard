# חרדים וגיוס

Brain: פוליטיקה
SubBrain: חרדים וגיוס

Purpose:
This folder is part of the Personal Brain structure.