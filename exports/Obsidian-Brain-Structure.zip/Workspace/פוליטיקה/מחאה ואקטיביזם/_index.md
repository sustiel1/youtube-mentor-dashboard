# מחאה ואקטיביזם

Brain: פוליטיקה
SubBrain: מחאה ואקטיביזם

Purpose:
This folder is part of the Personal Brain structure.