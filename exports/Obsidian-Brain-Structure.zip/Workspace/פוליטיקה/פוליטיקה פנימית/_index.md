# פוליטיקה פנימית

Brain: פוליטיקה
SubBrain: פוליטיקה פנימית

Purpose:
This folder is part of the Personal Brain structure.