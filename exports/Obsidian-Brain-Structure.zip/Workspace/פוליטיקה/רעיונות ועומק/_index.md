# רעיונות ועומק

Brain: פוליטיקה
SubBrain: רעיונות ועומק

Purpose:
This folder is part of the Personal Brain structure.