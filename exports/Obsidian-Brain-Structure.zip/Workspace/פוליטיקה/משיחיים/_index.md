# משיחיים

Brain: פוליטיקה
SubBrain: משיחיים

Purpose:
This folder is part of the Personal Brain structure.