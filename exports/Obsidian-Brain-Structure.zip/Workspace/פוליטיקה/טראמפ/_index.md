# טראמפ

Brain: פוליטיקה
SubBrain: טראמפ

Purpose:
This folder is part of the Personal Brain structure.