# דמוקרטיה ומוסדות

Brain: פוליטיקה
SubBrain: דמוקרטיה ומוסדות

Purpose:
This folder is part of the Personal Brain structure.