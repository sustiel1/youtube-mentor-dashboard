# שחיתות ושלטון

Brain: פוליטיקה
SubBrain: שחיתות ושלטון

Purpose:
This folder is part of the Personal Brain structure.