# צ׳קליסטים

Brain: ידע אישי
SubBrain: צ׳קליסטים

Purpose:
This folder is part of the Personal Brain structure.