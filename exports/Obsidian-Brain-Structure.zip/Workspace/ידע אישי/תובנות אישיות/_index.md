# תובנות אישיות

Brain: ידע אישי
SubBrain: תובנות אישיות

Purpose:
This folder is part of the Personal Brain structure.