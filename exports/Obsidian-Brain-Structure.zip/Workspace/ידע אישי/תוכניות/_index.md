# תוכניות

Brain: ידע אישי
SubBrain: תוכניות

Purpose:
This folder is part of the Personal Brain structure.