# ידע אישי

This folder is part of the Personal Brain structure.