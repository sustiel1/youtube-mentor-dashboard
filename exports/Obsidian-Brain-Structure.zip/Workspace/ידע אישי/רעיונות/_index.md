# רעיונות

Brain: ידע אישי
SubBrain: רעיונות

Purpose:
This folder is part of the Personal Brain structure.