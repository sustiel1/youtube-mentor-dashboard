# סיכומים

Brain: ידע אישי
SubBrain: סיכומים

Purpose:
This folder is part of the Personal Brain structure.