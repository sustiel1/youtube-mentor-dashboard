# למידה

Brain: ידע אישי
SubBrain: למידה

Purpose:
This folder is part of the Personal Brain structure.