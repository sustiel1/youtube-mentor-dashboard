# משימות

Brain: ידע אישי
SubBrain: משימות

Purpose:
This folder is part of the Personal Brain structure.