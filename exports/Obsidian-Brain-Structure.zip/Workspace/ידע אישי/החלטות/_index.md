# החלטות

Brain: ידע אישי
SubBrain: החלטות

Purpose:
This folder is part of the Personal Brain structure.