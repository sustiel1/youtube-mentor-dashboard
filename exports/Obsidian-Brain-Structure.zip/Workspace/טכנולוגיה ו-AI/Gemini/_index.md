# Gemini

Brain: טכנולוגיה ו-AI
SubBrain: Gemini

Purpose:
This folder is part of the Personal Brain structure.