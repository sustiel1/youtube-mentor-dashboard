# Ollama

Brain: טכנולוגיה ו-AI
SubBrain: Ollama

Purpose:
This folder is part of the Personal Brain structure.