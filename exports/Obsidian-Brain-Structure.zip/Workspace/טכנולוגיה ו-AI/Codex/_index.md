# Codex

Brain: טכנולוגיה ו-AI
SubBrain: Codex

Purpose:
This folder is part of the Personal Brain structure.