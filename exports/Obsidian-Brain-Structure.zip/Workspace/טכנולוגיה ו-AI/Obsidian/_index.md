# Obsidian

Brain: טכנולוגיה ו-AI
SubBrain: Obsidian

Purpose:
This folder is part of the Personal Brain structure.