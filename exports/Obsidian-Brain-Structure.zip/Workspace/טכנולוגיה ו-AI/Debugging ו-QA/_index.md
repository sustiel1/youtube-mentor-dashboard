# Debugging ו-QA

Brain: טכנולוגיה ו-AI
SubBrain: Debugging ו-QA

Purpose:
This folder is part of the Personal Brain structure.