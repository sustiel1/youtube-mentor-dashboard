# Frontend

Brain: טכנולוגיה ו-AI
SubBrain: Frontend

Purpose:
This folder is part of the Personal Brain structure.