# RAG ו-Knowledge Systems

Brain: טכנולוגיה ו-AI
SubBrain: RAG ו-Knowledge Systems

Purpose:
This folder is part of the Personal Brain structure.