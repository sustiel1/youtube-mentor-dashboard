# ChatGPT

Brain: טכנולוגיה ו-AI
SubBrain: ChatGPT

Purpose:
This folder is part of the Personal Brain structure.