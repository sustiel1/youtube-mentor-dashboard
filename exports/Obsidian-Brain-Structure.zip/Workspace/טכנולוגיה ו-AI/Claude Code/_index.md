# Claude Code

Brain: טכנולוגיה ו-AI
SubBrain: Claude Code

Purpose:
This folder is part of the Personal Brain structure.