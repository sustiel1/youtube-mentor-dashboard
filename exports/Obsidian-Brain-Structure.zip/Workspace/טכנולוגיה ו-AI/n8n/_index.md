# n8n

Brain: טכנולוגיה ו-AI
SubBrain: n8n

Purpose:
This folder is part of the Personal Brain structure.