# Backend

Brain: טכנולוגיה ו-AI
SubBrain: Backend

Purpose:
This folder is part of the Personal Brain structure.