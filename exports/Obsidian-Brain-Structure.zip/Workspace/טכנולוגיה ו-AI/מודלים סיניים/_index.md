# מודלים סיניים

Brain: טכנולוגיה ו-AI
SubBrain: מודלים סיניים

Purpose:
This folder is part of the Personal Brain structure.