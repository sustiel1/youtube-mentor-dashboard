# Automation

Brain: טכנולוגיה ו-AI
SubBrain: Automation

Purpose:
This folder is part of the Personal Brain structure.