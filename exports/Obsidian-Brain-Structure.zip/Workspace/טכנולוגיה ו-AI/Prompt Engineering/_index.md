# Prompt Engineering

Brain: טכנולוגיה ו-AI
SubBrain: Prompt Engineering

Purpose:
This folder is part of the Personal Brain structure.