# AI Workflows

Brain: טכנולוגיה ו-AI
SubBrain: AI Workflows

Purpose:
This folder is part of the Personal Brain structure.