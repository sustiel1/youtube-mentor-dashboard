# Local LLMs

Brain: טכנולוגיה ו-AI
SubBrain: Local LLMs

Purpose:
This folder is part of the Personal Brain structure.