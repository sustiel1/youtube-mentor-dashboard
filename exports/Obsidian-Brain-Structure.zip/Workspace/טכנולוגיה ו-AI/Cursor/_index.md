# Cursor

Brain: טכנולוגיה ו-AI
SubBrain: Cursor

Purpose:
This folder is part of the Personal Brain structure.