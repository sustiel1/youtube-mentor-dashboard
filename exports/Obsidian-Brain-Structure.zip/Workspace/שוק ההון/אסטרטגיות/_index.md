# אסטרטגיות

Brain: שוק ההון
SubBrain: אסטרטגיות

Purpose:
This folder is part of the Personal Brain structure.