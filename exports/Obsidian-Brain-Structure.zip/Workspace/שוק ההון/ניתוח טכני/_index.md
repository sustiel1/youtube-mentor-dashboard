# ניתוח טכני

Brain: שוק ההון
SubBrain: ניתוח טכני

Purpose:
This folder is part of the Personal Brain structure.