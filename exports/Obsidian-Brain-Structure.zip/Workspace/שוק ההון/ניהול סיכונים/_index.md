# ניהול סיכונים

Brain: שוק ההון
SubBrain: ניהול סיכונים

Purpose:
This folder is part of the Personal Brain structure.