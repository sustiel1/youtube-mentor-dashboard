# השקעות לטווח ארוך

Brain: שוק ההון
SubBrain: השקעות לטווח ארוך

Purpose:
This folder is part of the Personal Brain structure.