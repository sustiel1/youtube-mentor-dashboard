# מאקרו

Brain: שוק ההון
SubBrain: מאקרו

Purpose:
This folder is part of the Personal Brain structure.