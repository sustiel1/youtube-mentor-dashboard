# דוחות ורווחים

Brain: שוק ההון
SubBrain: דוחות ורווחים

Purpose:
This folder is part of the Personal Brain structure.