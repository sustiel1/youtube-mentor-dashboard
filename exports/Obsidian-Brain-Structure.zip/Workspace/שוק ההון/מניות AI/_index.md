# מניות AI

Brain: שוק ההון
SubBrain: מניות AI

Purpose:
This folder is part of the Personal Brain structure.