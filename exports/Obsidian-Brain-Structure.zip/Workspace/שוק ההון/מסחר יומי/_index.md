# מסחר יומי

Brain: שוק ההון
SubBrain: מסחר יומי

Purpose:
This folder is part of the Personal Brain structure.