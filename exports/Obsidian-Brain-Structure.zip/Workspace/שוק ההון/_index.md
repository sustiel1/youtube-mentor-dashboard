# שוק ההון

This folder is part of the Personal Brain structure.