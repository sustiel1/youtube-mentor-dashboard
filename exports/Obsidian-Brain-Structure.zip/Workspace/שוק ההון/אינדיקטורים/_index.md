# אינדיקטורים

Brain: שוק ההון
SubBrain: אינדיקטורים

Purpose:
This folder is part of the Personal Brain structure.