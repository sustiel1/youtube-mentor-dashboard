# טראמפ ושוק ההון

Brain: שוק ההון
SubBrain: טראמפ ושוק ההון

Purpose:
This folder is part of the Personal Brain structure.