# רשימות מעקב

Brain: שוק ההון
SubBrain: רשימות מעקב

Purpose:
This folder is part of the Personal Brain structure.