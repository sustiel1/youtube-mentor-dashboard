# מסחר סווינג

Brain: שוק ההון
SubBrain: מסחר סווינג

Purpose:
This folder is part of the Personal Brain structure.