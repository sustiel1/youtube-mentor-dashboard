# אופציות

Brain: שוק ההון
SubBrain: אופציות

Purpose:
This folder is part of the Personal Brain structure.