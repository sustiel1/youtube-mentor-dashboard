# שיטת הרצפים

Brain: שוק ההון
SubBrain: שיטת הרצפים

Purpose:
This folder is part of the Personal Brain structure.