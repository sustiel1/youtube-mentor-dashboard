# פונדמנטלי

Brain: שוק ההון
SubBrain: פונדמנטלי

Purpose:
This folder is part of the Personal Brain structure.